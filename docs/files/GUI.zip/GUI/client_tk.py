import zmq #zmq for both c++ and python is needed
import time
import webbrowser
import tkinter as tk
import tkinter.scrolledtext as tkst

from tkinter import *
from tkinter.ttk import *

#App window parameters
HEIGHT = 600
WIDTH = 680
url = "https://fpgaemu.rtfd.org"
new = 1

#Info function
def info():
    print("How to use the counter program:")
    print("Type an integer start value into text box and click Start.")
    print("++ to increment and -- to decrement the counter.")
    print("Stop or close window to stop program.")
    print("Click About to visit project website.")

#Open project website
def openurl():
    webbrowser.open(url, new = new)

#Print out DUT output to both GUI textbox and shell
def gui_print(func): 
    def redirector(input_str):
        try:
            console.insert(INSERT, input_str)
            return func(input_str)
        except:
            return func(input_str)
    return redirector

#Setting the initial value of the C++ counter
def initial_val(entry):
    print("Initial value set")
    initialVal = entry

    socket.send_string (initialVal)
    message = socket.recv()
    print("DUT reply:", message.decode('utf-8')) #If initialVal is 10, expected reply is "DUT reply: b'Start value is 10' "

#Increment the counter 10 times
def send_incr():
    buttonInput = "increment"
        
    #for i in range (1,10): #GUI print lags when incrementing multiple times, manual for now
    socket.send_string (buttonInput)
    message = socket.recv()
    print ("DUT reply:", message.decode('utf-8')) #Should stop at 'The counter is at 19'

#Decrement the counter 10 times
def send_decr():
    buttonInput = "decrement"

    #for i in range (1,10):
    socket.send_string (buttonInput)
    message = socket.recv()
    print ("DUT reply:", message.decode('utf-8')) #Should stop at 'The counter is at 10'

#Stop the counter DUT, immediately exit out of both scripts
def send_stop():
    buttonInput = "stop"

    print("Stopping the DUT")
    socket.send_string (buttonInput)
    message = socket.recv()
    print ("DUT reply:", message.decode('utf-8')) #Should stop at 'The counter finished at 10'
    quit() #Both .py and .cpp should exit at this point

#Python server and C++ DUT communicate using the ZeroMQ library
#Python sends appropriate commands ("start, stop" etc.) to the C++ DUT
#C++ program replies back with computational results (ex. where the counter is at now)

context = zmq.Context()
socket = context.socket(zmq.REQ) #Uses TCP sockets for local communication
port = "5555"
socket.connect ("tcp://localhost:%s" % port) #Bind to port 5555

#Setting up simple GUI (tkinter installation is needed ~ apt-get install python3-tk)
root = tk.Tk()
root.title('DUT Counter')

canvas = tk.Canvas(root, height = HEIGHT, width = WIDTH) #create entire app window
canvas.pack()

side_frame = tk.Frame(root, bg = '#80c1ff', bd = 10) #frame for counter buttons
side_frame.place(relwidth = 0.14, relheight = 1)

frame = tk.Frame(root, bg = '#80c1ff', bd = 5) #start button frame
frame.place(relx = 0.55, rely = 0.05, relwidth = 0.75, relheight = 0.1, anchor ='n')

lower_frame = tk.Frame(root, bg = '#80c1ff', bd =10) #console frame
lower_frame.place(relx = 0.55,rely = 0.2, relwidth = 0.75, relheight = 0.35, anchor = 'n')

entry = tk.Entry(frame, font = 40)
entry.place(relwidth = 0.65, relheight =1)

start_bt = tk.Button(frame, text = "Start", font = 40, command = lambda: initial_val(entry.get())) #set initial value from stdin
start_bt.place(relx = 0.7, rely =0, relwidth = 0.3, relheight = 1)

incr_bt = tk.Button(side_frame, text = "++", font = 40, command = send_incr) #invoke increment command
incr_bt.place(relheight = 0.15, relwidth = 0.99)

decr_bt = tk.Button(side_frame, text = "--", font = 40, command = send_decr) #invoke decrement command
decr_bt.place(rely = 0.2, relheight = 0.15, relwidth = 0.99)

stop_bt = tk.Button(side_frame, text = "Stop", font = 40, command = send_stop) #invoke stop command
stop_bt.place(rely = 0.4, relheight = 0.15, relwidth = 0.99)

info_bt = tk.Button(side_frame, text = "Info", font = 40, command = info)
info_bt.place(rely = 0.6, relheight = 0.15, relwidth = 0.99)

url_bt = tk.Button(side_frame, text = "About", font = 40, command = openurl)
url_bt.pack()
url_bt.place(rely = 0.8, relheight = 0.15, relwidth = 0.99)

#text_box = Text(lower_frame, width = 40,height = 60, bg = 'light grey',font = 40 ) #console output, does not do anything
#text_box.place(relx = 0.45, rely = 0.35, relheight = 0.55, relwidth = 0.55)
console = tkst.ScrolledText(lower_frame)
console.pack()
sys.stdout.write = gui_print(sys.stdout.write)

usd_img = PhotoImage(file="usd.png")
canvas.create_image(50,350, anchor = NW, image = usd_img)

q_img = PhotoImage(file="q.png")
q_img = q_img.zoom(20)
q_img = q_img.subsample(32)
canvas.create_image(300,270, anchor = NW, image = q_img)

root.mainloop() #tkinter loop, exits when invoking stop command or closing out of app window