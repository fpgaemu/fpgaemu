/* Simple counter DUT (must have zmq.hpp to function properly)
 * Communicates with python client using ZeroMQ library and TCP sockets
 * Server/client text commands must match using string registers
 * Add in comments about not having FPGA, simulation; when HW is obtained, client should act in a similar fashion
 */

#include <zmq.hpp>
#include <iostream>
#include <unistd.h>

int main() {
    //  Prepare our context and socket
    zmq::context_t context(1);
    zmq::socket_t socket(context, ZMQ_REP);
    socket.bind("tcp://*:5555");

    std::string register_1; //increment/decrement/stop (assumes start)
    std::string register_2; //set initial start value
    int count;

    while (true) { //wait until detect user input

        zmq::message_t startVal; //check for start value
        socket.recv(&startVal); //assumes first command will be initial value
        std::string confirmation = std::string(static_cast<char *>(startVal.data()), startVal.size());
        register_2 = confirmation;
        std::cout << "Start value is: " + register_2 << std::endl;
        count = std::stoi(register_2);

        sleep(1);

        //  Send reply back to client
        std::string startMsg("Start value is " + register_2);
        zmq::message_t startReply(startMsg.size());
        memcpy((void *) startReply.data(), (startMsg.c_str()), startMsg.size());
        socket.send(startReply);
        
        break; //transition into counter loop
    }

    // infinite loop for counter
    while (true) {
        zmq::message_t request;

        //  Wait for next request from client, assuming string command
        socket.recv(&request);
        std::string replyMessage = std::string(static_cast<char *>(request.data()), request.size());
        // Print out received message
        register_1 = replyMessage;
        std::cout << "Received from client: " + register_1 << std::endl;

        // Three DUT functions: ++, --, stop; aligns with client.py commands
        if(register_1 == "increment") {
            count = count + 1;
            std::cout << "The counter is at " << count << std::endl; 
        } else if (register_1 == "decrement") {
            count = count - 1;            
            std::cout << "The counter is at " << count << std::endl;
        } else if (register_1 == "stop") { // if stop, send final report
            std::string final_count = std::to_string(count);
            std::string stopMsg("The counter finished at " + final_count);
            zmq::message_t stopReply(stopMsg.size());
            memcpy((void *) stopReply.data(), (stopMsg.c_str()), stopMsg.size());
            socket.send(stopReply);
            break; //stop immediately
        }

        // Incremental sending/replying between server, client
        sleep(1);
        std::string curr_count = std::to_string(count);

        //  Send reply back to verify DUT functions
        std::string msgToClient("The counter is at " + curr_count);
        zmq::message_t reply(msgToClient.size());
        memcpy((void *) reply.data(), (msgToClient.c_str()), msgToClient.size());
        socket.send(reply);
    }
    return 0;
}